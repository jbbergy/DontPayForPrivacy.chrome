try {
    importScripts("providers/didomi.js");
  } catch (e) {
    console.error(e);
  }