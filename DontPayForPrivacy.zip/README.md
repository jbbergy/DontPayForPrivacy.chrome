# DontPayForPrivacy
An extension to remove a website popin asking you to pay to not get tracked by cookies - you can freely browse the website thanks to this extension.
## Todo
* Add more providers. Actualy we manage only Didomi solution
## Installation
1. Open Chrome extension page ```chrome://extensions/```
2. Activate developer mode with the top right toggle
3. Click on "load unpacked extension" with the button ont the top right
